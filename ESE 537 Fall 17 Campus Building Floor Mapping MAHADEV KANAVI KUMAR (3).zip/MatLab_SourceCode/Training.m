clc;
clear all;
close all;
input_location='C:\Users\Nagaratna\Desktop\MSSProject\new\Training\';
database_length=100;
Sampl_bit = 16; 
over_lap = 100;
window_length = 256;
for i = 1:database_length
    file = sprintf('%ss%d.wav',input_location,i);    
    disp('processing');
    disp(i);
     [speech, sampl_frq] = audioread(file);
     leng = length(speech);
    frame_calc = floor((leng - window_length) / over_lap) + 1;
    for ii = 1:window_length
    for j = 1:frame_calc
        Mel(ii, j) = speech(((j - 1) * over_lap) + ii);
    end
    end
    coeffient = hamming(window_length);
    Mel_revised = diag(coeffient) * Mel;
    for k = 1:frame_calc
    framing(:,k) = fft(Mel_revised(:, k));
    end


Initial_frq = 700 / sampl_frq;
cutoff = floor(window_length/2);
disp('level1');
scaling = log(1 + 0.5/Initial_frq) / (20+1);


Bin_freq = window_length * (Initial_frq * (exp([0 1 20 20+1] * scaling) - 1));

bank1 = floor(Bin_freq(1)) + 1;
bank2 = ceil(Bin_freq(2));
bank3 = floor(Bin_freq(3));
bank4 = min(cutoff, ceil(Bin_freq(4))) - 1;
disp('level2');
pass_band = log(1 + (bank1:bank4)/window_length/Initial_frq) / scaling;
pass_band_freq = floor(pass_band);
message = pass_band - pass_band_freq;
disp('level3');
row_dat = [pass_band_freq(bank2:bank4) 1+pass_band_freq(1:bank3)];
colum_dat = [bank2:bank4 1:bank3] + 1;
vect = 2 * [1-message(bank2:bank4) message(1:bank3)];
disp('level4');
win_opt = 1 + floor(window_length / 2);
zero_cross = over_lap * abs(framing(1:win_opt, :)).^2;
disp('level5');
root_cosine = dct(log(zero_cross));
quantiz   = .01;
avg_root   = mean(root_cosine, 2);
data_pointr = 10000;
disp('level6');
for kk = 1:log2(Sampl_bit)
    avg_root = [avg_root*(1+quantiz), avg_root*(1-quantiz)];
    
    while (1 == 1)
        position_revis = localization(root_cosine, avg_root);
        [~,ind] = min(position_revis, [], 2);
        tim_slot = 0;
        for j = 1:2^kk
            avg_root(:, j) = mean(root_cosine(:, find(ind == j)), 2);
            x = localization(root_cosine(:, find(ind == j)), avg_root(:, j));
            for q = 1:length(x)
                tim_slot = tim_slot + x(q);
            end
        end
        if (((data_pointr - tim_slot)/tim_slot) < quantiz)
            break;
        else
            data_pointr = tim_slot;
        end
    end    
   data_base_book{i}=avg_root;
end
disp('level7');
end
save('test.mat', 'data_base_book');