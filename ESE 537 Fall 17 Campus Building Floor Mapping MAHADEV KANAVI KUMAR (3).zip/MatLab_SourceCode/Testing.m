clc;
clear all;
close all;
window_length = 256;
 [speech, sampl_frq] = audioread('s1.wav');
 leng = length(speech);
 figure;
 plot(speech);
 title('Testing');
 k=1;
n=1;
load ('test.mat','data_base_book'); 
Sampl_bit = 16; 
over_lap = 100;
  frame_calc = floor((leng - window_length) / over_lap) + 1;
    for ii = 1:window_length
    for j = 1:frame_calc
        Mel(ii, j) = speech(((j - 1) * over_lap) + ii);
    end
    end


    coeffient = hamming(window_length);


    Mel_revised = diag(coeffient) * Mel;
    for k = 1:frame_calc
    framing(:,k) = fft(Mel_revised(:, k));
    if k==100
        t=1:256;
 figure;
 plot(t,framing);
 title('Spectrum');

    end
    end
    Initial_frq = 700 / sampl_frq;
cutoff = floor(window_length/2);

scaling = log(1 + 0.5/Initial_frq) / (20+1);


Bin_freq = window_length * (Initial_frq * (exp([0 1 20 20+1] * scaling) - 1));

bank1 = floor(Bin_freq(1)) + 1;
bank2 = ceil(Bin_freq(2));
bank3 = floor(Bin_freq(3));
bank4 = min(cutoff, ceil(Bin_freq(4))) - 1;

pass_band = log(1 + (bank1:bank4)/window_length/Initial_frq) / scaling;
pass_band_freq = floor(pass_band);
message = pass_band - pass_band_freq;

row_dat = [pass_band_freq(bank2:bank4) 1+pass_band_freq(1:bank3)];
colum_dat = [bank2:bank4 1:bank3] + 1;
vect = 2 * [1-message(bank2:bank4) message(1:bank3)];

win_opt = 1 + floor(window_length / 2);
zero_cross = over_lap * abs(framing(1:win_opt, :)).^2;
figure;
plot(zero_cross);
title('Zero crossing');

root_cosine = dct(log(zero_cross));
figure;
plot(root_cosine);
title('DCT');

save('out.mat','root_cosine');
index_posi = inf;
    k1 = 0;
      for l = 1:length(data_base_book)
        d = localization(root_cosine, data_base_book{l}); 
        diff_valu = sum(min(d,[],2)) / size(d,1);
      
        if diff_valu < index_posi
            index_posi = diff_valu;
            k1 = l;
        end      
    end
    if k1>=1 && k1<=30
    h=sprintf('Door');
    elseif k1>=31 && k1<=50
    h=sprintf('Stairs');
    elseif k1>=51 && k1<=70
    h=sprintf('Water Fountain');  
    elseif k1>=71 && k1<=90
    h=sprintf('Open Space');
      elseif k1>=91 && k1<=100
    h=sprintf('Wall');
    else
    h=sprintf('Confusion');
    end                     
    
    disp(h);