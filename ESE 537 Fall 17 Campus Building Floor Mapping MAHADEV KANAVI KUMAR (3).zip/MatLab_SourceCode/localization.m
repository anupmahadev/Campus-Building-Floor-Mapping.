function position = localization(root_cosine, data)
       

[~, col_dats] = size(root_cosine);
[~, pointer] = size(data); 


position = zeros(col_dats, pointer);

if (col_dats < pointer)
    copies = zeros(1,pointer);
    for n = 1:col_dats
        position(n,:) = sum((root_cosine(:, n+copies) - data) .^2, 1);
    end
else
    copies = zeros(1,col_dats);
    for p = 1:pointer
        position(:,p) = sum((root_cosine - data(:, p+copies)) .^2, 1)';
    end
end

position = position.^0.5;
